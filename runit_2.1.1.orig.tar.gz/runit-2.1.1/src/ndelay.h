/* Public domain. */

#ifndef NDELAY_H
#define NDELAY_H

extern int ndelay_on(int);
extern int ndelay_off(int);

#endif
