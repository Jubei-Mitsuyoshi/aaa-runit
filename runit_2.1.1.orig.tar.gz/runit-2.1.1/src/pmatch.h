#ifndef PMATCH_H
#define PMATCH_H

extern unsigned int pmatch(const char *, const char *, unsigned int);

#endif
